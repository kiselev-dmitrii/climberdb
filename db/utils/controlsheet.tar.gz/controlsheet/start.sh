sleep 1 && ./main
